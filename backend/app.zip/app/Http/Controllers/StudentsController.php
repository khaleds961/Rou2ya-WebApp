<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Students;
use Exception;

class StudentsController extends Controller
{

    public function addstudent(request $request)
    {
        $student = new Students;
        try {
            $student->fill($request->all());
            $student->save();
        } catch (Exception $e) {
            return response()->json($e);
        }
    }

    public function getstudentsPg()
    {
        return Students::paginate(5);
    }

    public function getstudents()
    {
        return Students::all();
    }


    public function getstudentbyid($id)
    {
        $row = Students::where('id', $id)->get();
        
        if (count($row) === 1) {
             return true;
         } else {
            return false;
         }
    }

    public function editstudent(request $request, $id)
    {
        try{
        if (self::getstudentbyid($id)) {
            $student = Students::where('id', $id)->first();
            $student->update($request->all());
        } else {
            return 'Wrong Id';
        }
    }
    catch(Exception $e){
        return $e;
    }

    }

    public function deletestudent($id){
        try{
            if(self::getstudentbyid($id)){
        $students = Students::where('id',$id)->delete();
            }else{
                return 'Wrong Id!!';
            }
        }
        catch(Exception $e){
            return $e;
        }
    }


}
