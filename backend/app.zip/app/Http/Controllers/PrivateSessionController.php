<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PrivateSession;
use Exception;


class PrivateSessionController extends Controller
{
    public function addPrivateSession(request $request)
    {
        $private = new PrivateSession;
        try {
            $private->fill($request->all());
            $private->save();
        } catch (Exception $e) {
            return response()->json($e);
        }
    }

    public function getPrivateSession()
    {
        return PrivateSession::all();
    }


    public function getPrivateSessionbyid($id)
    {
        $row = PrivateSession::where('id', $id)->get();
        
        if (count($row) === 1) {
             return true;
         } else {
            return false;
         }
    }

    public function editPrivateSession(request $request, $id)
    {
        try{
        if (self::getPrivateSessionbyid($id)) {
            $private = PrivateSession::where('id', $id)->first();
            $private->update($request->all());
        } else {
            return 'Wrong Id';
        }
    }
    catch(Exception $e){
        return $e;
    }

    }

    public function deletePrivateSession($id){
        try{
            if(self::getPrivateSessionbyid($id)){
        $private = PrivateSession::where('id',$id)->delete();
            }else{
                return 'Wrong Id!!';
            }
        }
        catch(Exception $e){
            return $e;
        }
    }

}
